<?php
/**
* Plugin Name: Display Post Iteration
* Description: A simple plugin to display the post iteration count at any position in the post content.
* Version: 1.0
* Author: ZiXue.IO
*/
// Add a shortcode to display the post iteration count
function display_post_iteration_shortcode($atts) {
global $post;
$iteration_count = get_post_meta($post->ID, 'iteration_count', true);
if (!$iteration_count) {
$iteration_count = 1;
update_post_meta($post->ID, 'iteration_count', $iteration_count);
}
return $iteration_count;
}
add_shortcode('display_post_iteration', 'display_post_iteration_shortcode');
// Update the post iteration count on each post save
function update_post_iteration_count($post_id) {
$iteration_count = get_post_meta($post_id, 'iteration_count', true);
if (!$iteration_count) {
$iteration_count = 1;
} else {
$iteration_count++;
}
update_post_meta($post_id, 'iteration_count', $iteration_count);
}
add_action('save_post', 'update_post_iteration_count');
?>